-- Script para crear tablas
CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    apellido_paterno TEXT,
    calle TEXT,
    numero TEXT,
    colonia TEXT,
    cp TEXT,
    ciudad TEXT,
    estado TEXT,
    telefono TEXT
);

CREATE TABLE IF NOT EXISTS articulos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    precio REAL,
    precio_proveedor REAL,
    proveedor TEXT,
    stock INTEGER
);