// src/main/java/org/example/abarrotes_tizimin/persistencia/DatabaseConfig.java
package org.example.abarrotes_tizimin.persistencia;

import java.sql.*;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class DatabaseConfig {
    private static final String URL = "jdbc:sqlite:abarrotes.db";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void inicializarBD() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            InputStream input = DatabaseConfig.class.getResourceAsStream("/sql/crear_tablas.sql");
            if (input == null) {
                System.err.println("No se encontró el archivo crear_tablas.sql");
                return;
            }
            String sql = new String(input.readAllBytes(), StandardCharsets.UTF_8);

            for (String sentencia : sql.split(";")) {
                if (!sentencia.trim().isEmpty()) {
                    stmt.execute(sentencia.trim());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}