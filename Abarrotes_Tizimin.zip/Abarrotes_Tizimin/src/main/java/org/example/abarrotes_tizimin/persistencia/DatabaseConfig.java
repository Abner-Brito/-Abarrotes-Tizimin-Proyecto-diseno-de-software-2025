package org.example.abarrotes_tizimin.persistencia;

import java.sql.*;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Clase de configuración y gestión de la base de datos SQLite.
 * Implementa el patrón Singleton para asegurar una única instancia de conexión.
 * Permite obtener conexiones y ejecutar la inicialización de la base de datos a partir de un script SQL.
 */
public class DatabaseConfig {
    private static final String URL = "jdbc:sqlite:abarrotes.db";
    private static DatabaseConfig instancia;

    /**
     * Constructor privado para evitar instanciación externa (Singleton).
     */
    private DatabaseConfig() {}

    /**
     * Obtiene la instancia única de DatabaseConfig.
     * @return Instancia única de DatabaseConfig.
     */
    public static synchronized DatabaseConfig getInstancia() {
        if (instancia == null) {
            instancia = new DatabaseConfig();
        }
        return instancia;
    }

    /**
     * Obtiene una nueva conexión a la base de datos SQLite.
     * @return Objeto Connection para interactuar con la base de datos.
     * @throws SQLException Si ocurre un error al conectar.
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    /**
     * Inicializa la base de datos ejecutando el script SQL ubicado en /sql/crear_tablas.sql.
     * Crea las tablas necesarias si no existen.
     */
    public static void inicializarBD() {
        try (Connection conn = getInstancia().getConnection();
             Statement stmt = conn.createStatement()) {

            InputStream input = DatabaseConfig.class.getResourceAsStream("/sql/crear_tablas.sql");
            if (input == null) {
                System.err.println("No se encontró el archivo crear_tablas.sql");
                return;
            }
            String sql = new String(input.readAllBytes(), StandardCharsets.UTF_8);

            for (String sentencia : sql.split(";")) {
                if (!sentencia.trim().isEmpty()) {
                    stmt.execute(sentencia.trim());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}