// src/main/java/org/example/abarrotes_tizimin/controlador/ListaArticulosController.java
package org.example.abarrotes_tizimin.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.abarrotes_tizimin.modelo.Articulo;
import org.example.abarrotes_tizimin.persistencia.ArticuloDAO;

public class ListaArticulosController {
    @FXML private TableView<Articulo> tablaArticulos;
    @FXML private TableColumn<Articulo, Integer> colId;
    @FXML private TableColumn<Articulo, String> colNombre;
    @FXML private TableColumn<Articulo, Double> colPrecio;
    @FXML private TableColumn<Articulo, Double> colPrecioProveedor;
    @FXML private TableColumn<Articulo, String> colProveedor;
    @FXML private TableColumn<Articulo, Integer> colStock;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
        colPrecioProveedor.setCellValueFactory(new PropertyValueFactory<>("precioProveedor"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));
        colProveedor.setCellValueFactory(new PropertyValueFactory<>("proveedor"));
        tablaArticulos.getItems().setAll(ArticuloDAO.obtenerTodosArticulos());
    }
    // src/main/java/org/example/abarrotes_tizimin/controlador/ListaArticulosController.java
    @FXML
    private void eliminarArticulo() {
        Articulo seleccionado = tablaArticulos.getSelectionModel().getSelectedItem();
        if (seleccionado != null) {
            boolean exito = ArticuloDAO.eliminarArticulo(seleccionado.getId());
            if (exito) {
                tablaArticulos.getItems().remove(seleccionado);
            } else {
                System.err.println("No se pudo eliminar el artículo.");
            }
        }
    }
@FXML
private javafx.scene.control.Label lblMensaje;



@FXML
private void aumentarStock() {
    lblMensaje.setText(""); // Limpia mensaje anterior
    Articulo seleccionado = tablaArticulos.getSelectionModel().getSelectedItem();
    if (seleccionado == null) {
        lblMensaje.setText("Selecciona un artículo.");
        return;
    }

    javafx.scene.control.TextInputDialog dialog = new javafx.scene.control.TextInputDialog();
    dialog.setTitle("Aumentar Stock");
    dialog.setHeaderText("Ingrese la cantidad a agregar:");
    dialog.setContentText("Cantidad:");

    dialog.showAndWait().ifPresent(input -> {
        try {
            int cantidadAAgregar = Integer.parseInt(input);
            if (cantidadAAgregar > 0) {
                boolean exito = ArticuloDAO.aumentarStock(seleccionado.getId(), cantidadAAgregar);
                if (exito) {
                    seleccionado.setStock(seleccionado.getStock() + cantidadAAgregar);
                    tablaArticulos.refresh();
                    lblMensaje.setText("Stock aumentado correctamente.");
                } else {
                    lblMensaje.setText("No se pudo aumentar el stock.");
                }
            } else {
                lblMensaje.setText("Ingresa una cantidad válida.");
            }
        } catch (NumberFormatException e) {
            lblMensaje.setText("Ingresa una cantidad válida.");
        }
    });
}
}