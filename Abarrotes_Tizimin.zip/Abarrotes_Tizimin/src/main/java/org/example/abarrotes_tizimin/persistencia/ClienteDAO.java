package org.example.abarrotes_tizimin.persistencia;

import org.example.abarrotes_tizimin.modelo.Cliente;
import org.example.abarrotes_tizimin.modelo.Direccion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
  public void guardarCliente(Cliente cliente) {
      String sql = "INSERT INTO clientes (nombre, apellido_paterno, calle, numero, colonia, cp, ciudad, estado, telefono) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
      try (Connection conn = DatabaseConfig.getConnection();
           PreparedStatement pstmt = conn.prepareStatement(sql)) {
          pstmt.setString(1, cliente.getNombre());
          pstmt.setString(2, cliente.getApellidoPaterno());
          pstmt.setString(3, cliente.getCalle());
          pstmt.setString(4, cliente.getNumero());
          pstmt.setString(5, cliente.getColonia());
          pstmt.setString(6, cliente.getCp());
          pstmt.setString(7, cliente.getCiudad());
          pstmt.setString(8, cliente.getEstado());
          pstmt.setString(9, cliente.getTelefono());
          pstmt.executeUpdate();
      } catch (SQLException e) {
          e.printStackTrace();
      }
  }

    // En ClienteDAO.java
    public List<Cliente> obtenerTodosClientes() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT id, nombre, apellido_paterno, calle, numero, colonia, cp, ciudad, estado, telefono FROM clientes";
        try (Connection conn = DatabaseConfig.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Direccion direccion = new Direccion(
                    rs.getString("calle"),
                    rs.getString("numero"),
                    rs.getString("colonia"),
                    rs.getString("cp"),
                    rs.getString("ciudad"),
                    rs.getString("estado")
                );
                Cliente cliente = new Cliente(
                    rs.getString("nombre"),
                    rs.getString("apellido_paterno"),
                    direccion,
                    rs.getString("telefono")
                );
                cliente.setId(rs.getInt("id"));
                clientes.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clientes;
    }
// En ClienteDAO.java
public boolean insertarCliente(Cliente cliente) {
    String sql = "INSERT INTO clientes (nombre, apellido_paterno, calle, numero, colonia, cp, ciudad, estado, telefono) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, cliente.getNombre());
        pstmt.setString(2, cliente.getApellidoPaterno());
        pstmt.setString(3, cliente.getCalle());
        pstmt.setString(4, cliente.getNumero());
        pstmt.setString(5, cliente.getColonia());
        pstmt.setString(6, cliente.getCp());
        pstmt.setString(7, cliente.getCiudad());
        pstmt.setString(8, cliente.getEstado());
        pstmt.setString(9, cliente.getTelefono());
        int filas = pstmt.executeUpdate();
        return filas > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
}