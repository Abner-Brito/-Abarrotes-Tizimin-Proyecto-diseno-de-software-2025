package org.example.abarrotes_tizimin.persistencia;

import org.example.abarrotes_tizimin.modelo.Cliente;
import org.example.abarrotes_tizimin.modelo.Direccion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase de acceso a datos (DAO) para la entidad Cliente.
 * Permite realizar operaciones CRUD sobre la tabla de clientes en la base de datos.
 */
public class ClienteDAO {

    /**
     * Guarda un nuevo cliente en la base de datos.
     * @param cliente El cliente a guardar.
     */
    public void guardarCliente(Cliente cliente) {
        String sql = "INSERT INTO clientes (nombre, apellido_paterno, calle, numero, colonia, cp, ciudad, estado, telefono) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cliente.getNombre());
            pstmt.setString(2, cliente.getApellidoPaterno());
            pstmt.setString(3, cliente.getCalle());
            pstmt.setString(4, cliente.getNumero());
            pstmt.setString(5, cliente.getColonia());
            pstmt.setString(6, cliente.getCp());
            pstmt.setString(7, cliente.getCiudad());
            pstmt.setString(8, cliente.getEstado());
            pstmt.setString(9, cliente.getTelefono());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Obtiene todos los clientes almacenados en la base de datos.
     * @return Lista de objetos Cliente.
     */
    public List<Cliente> obtenerTodosClientes() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT id, nombre, apellido_paterno, calle, numero, colonia, cp, ciudad, estado, telefono FROM clientes";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Direccion direccion = new Direccion(
                    rs.getString("calle"),
                    rs.getString("numero"),
                    rs.getString("colonia"),
                    rs.getString("cp"),
                    rs.getString("ciudad"),
                    rs.getString("estado")
                );
                Cliente cliente = new Cliente(
                    rs.getString("nombre"),
                    rs.getString("apellido_paterno"),
                    direccion,
                    rs.getString("telefono")
                );
                cliente.setId(rs.getInt("id"));
                clientes.add(cliente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clientes;
    }

    /**
     * Inserta un nuevo cliente en la base de datos.
     * @param cliente El cliente a insertar.
     * @return true si la operación fue exitosa, false en caso contrario.
     */
    public boolean insertarCliente(Cliente cliente) {
        String sql = "INSERT INTO clientes (nombre, apellido_paterno, calle, numero, colonia, cp, ciudad, estado, telefono) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cliente.getNombre());
            pstmt.setString(2, cliente.getApellidoPaterno());
            pstmt.setString(3, cliente.getCalle());
            pstmt.setString(4, cliente.getNumero());
            pstmt.setString(5, cliente.getColonia());
            pstmt.setString(6, cliente.getCp());
            pstmt.setString(7, cliente.getCiudad());
            pstmt.setString(8, cliente.getEstado());
            pstmt.setString(9, cliente.getTelefono());
            int filas = pstmt.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Elimina un cliente de la base de datos por su ID.
     * @param id ID del cliente a eliminar.
     * @return true si la operación fue exitosa, false en caso contrario.
     */
    public boolean eliminarCliente(int id) {
        String sql = "DELETE FROM clientes WHERE id = ?";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Actualiza los datos de un cliente existente en la base de datos.
     * @param cliente El cliente con los datos actualizados.
     * @return true si la operación fue exitosa, false en caso contrario.
     */
    public boolean actualizarCliente(Cliente cliente) {
        String sql = "UPDATE clientes SET nombre=?, apellido_paterno=?, calle=?, numero=?, colonia=?, cp=?, ciudad=?, estado=?, telefono=? WHERE id=?";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, cliente.getNombre());
            pstmt.setString(2, cliente.getApellidoPaterno());
            pstmt.setString(3, cliente.getCalle());
            pstmt.setString(4, cliente.getNumero());
            pstmt.setString(5, cliente.getColonia());
            pstmt.setString(6, cliente.getCp());
            pstmt.setString(7, cliente.getCiudad());
            pstmt.setString(8, cliente.getEstado());
            pstmt.setString(9, cliente.getTelefono());
            pstmt.setInt(10, cliente.getId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}