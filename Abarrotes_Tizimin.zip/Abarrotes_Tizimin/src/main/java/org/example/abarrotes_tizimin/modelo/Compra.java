package org.example.abarrotes_tizimin.modelo;

public class Compra {
    private Articulo articulo;
    private int cantidad;

    public Compra(Articulo articulo, int cantidad) {
        this.articulo = articulo;
        this.cantidad = cantidad;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public int getCantidad() {
        return cantidad;
    }
}