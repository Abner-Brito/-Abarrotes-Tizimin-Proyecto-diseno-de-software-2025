package org.example.abarrotes_tizimin.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import org.example.abarrotes_tizimin.modelo.DetalleCompra;
import java.util.List;

public class TicketController {
    @FXML private Label lblFecha;
    @FXML private Label lblCliente;
    @FXML private ListView<String> listaArticulos;
    @FXML private Label lblTotal;

    public void generarTicket(List<DetalleCompra> detalles, double total, String nombreCliente, String fecha) {
        lblFecha.setText("Fecha: " + fecha);
        lblCliente.setText("Cliente: " + nombreCliente);
        listaArticulos.getItems().clear();
        for (DetalleCompra detalle : detalles) {
            String item = String.format(
                    "%s x%d - $%.2f c/u",
                    detalle.getArticulo().getNombre(),
                    detalle.getCantidad(),
                    detalle.getArticulo().getPrecio()
            );
            listaArticulos.getItems().add(item);
        }
        lblTotal.setText(String.format("Total: $%.2f", total));

    }
}