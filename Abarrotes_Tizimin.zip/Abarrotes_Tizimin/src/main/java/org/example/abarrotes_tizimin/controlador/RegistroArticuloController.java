// src/main/java/org/example/abarrotes_tizimin/controlador/RegistroArticuloController.java
package org.example.abarrotes_tizimin.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import org.example.abarrotes_tizimin.modelo.Articulo;
import org.example.abarrotes_tizimin.persistencia.ArticuloDAO;

public class RegistroArticuloController {

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtPrecio;

    @FXML
    private TextField txtPrecioProveedor;

    @FXML
    private TextField txtProveedor;

    @FXML
    private TextField txtStock;

    @FXML
    private void guardarArticulo() {
        try {
            String nombre = txtNombre.getText();
            double precio = Double.parseDouble(txtPrecio.getText());
            double precioProveedor = Double.parseDouble(txtPrecioProveedor.getText());
            String proveedor = txtProveedor.getText();
            int stock = Integer.parseInt(txtStock.getText());

            if (nombre.isEmpty() || precio <= 0 || precioProveedor <= 0 || proveedor.isEmpty() || stock < 0) {
                mostrarAlerta("Error", "Por favor, ingresa valores válidos.");
                return;
            }

            Articulo articulo = new Articulo();
            articulo.setNombre(nombre);
            articulo.setPrecio(precio);
            articulo.setPrecioProveedor(precioProveedor);
            articulo.setProveedor(proveedor);
            articulo.setStock(stock);

            boolean exito = ArticuloDAO.insertarArticulo(articulo);

            if (exito) {
                mostrarAlerta("Éxito", "Artículo registrado correctamente.");
                limpiarCampos();
            } else {
                mostrarAlerta("Error", "No se pudo registrar el artículo.");
            }
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "Por favor, ingresa valores numéricos válidos para precio, precio del proveedor y stock.");
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtPrecio.clear();
        txtPrecioProveedor.clear();
        txtProveedor.clear();
        txtStock.clear();
    }
}