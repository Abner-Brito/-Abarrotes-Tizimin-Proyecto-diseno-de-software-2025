package org.example.abarrotes_tizimin.controlador;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class HelloController {

    @FXML
    private void abrirRegistroCliente() throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/org/example/abarrotes_tizimin/vista/registro-cliente.fxml")
        );
        Stage stage = new Stage();
        stage.setScene(new Scene(loader.load()));
        stage.setTitle("Registrar Cliente");
        stage.show();
    }

    @FXML
    private void salir() {
        System.exit(0);
    }

@FXML
private void abrirRegistroArticulo() {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/abarrotes_tizimin/vista/registro-articulo.fxml"));
        Scene scene = new Scene(loader.load());
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setTitle("Registrar Artículo");
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
@FXML
public void abrirRealizarCompra(ActionEvent actionEvent) throws IOException {
    FXMLLoader loader = new FXMLLoader(
        getClass().getResource("/org/example/abarrotes_tizimin/vista/realizar-compra.fxml")
    );
    Stage stage = new Stage();
    stage.setScene(new Scene(loader.load()));
    stage.setTitle("Realizar Compra");
    stage.show();
}
    @FXML
    private void abrirListaClientes() throws IOException {
        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/org/example/abarrotes_tizimin/vista/lista-clientes.fxml")
        );
        Stage stage = new Stage();
        stage.setScene(new Scene(loader.load()));
        stage.setTitle("Lista de Clientes");
        stage.show();
    }

   @FXML
   private void abrirListaArticulos() throws IOException {
       FXMLLoader loader = new FXMLLoader(
           getClass().getResource("/org/example/abarrotes_tizimin/vista/lista-articulos.fxml")
       );
       Stage stage = new Stage();
       stage.setScene(new Scene(loader.load()));
       stage.setTitle("Lista de Artículos");
       stage.show();
   }
}