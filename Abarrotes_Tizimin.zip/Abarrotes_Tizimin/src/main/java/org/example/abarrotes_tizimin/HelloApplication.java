package org.example.abarrotes_tizimin; // Paquete correcto

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import org.example.abarrotes_tizimin.persistencia.DatabaseConfig;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // Ruta FXML ajustada (carpeta con puntos)
        FXMLLoader loader = new FXMLLoader(
            HelloApplication.class.getResource("/org/example/abarrotes_tizimin/vista/hello-view.fxml")
        );

        Scene scene = new Scene(loader.load(), 600, 400);

        scene.getStylesheets().add(
            HelloApplication.class.getResource("/css/styles.css").toExternalForm()
        );

        stage.setTitle("Abarrotes Tizimín");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        DatabaseConfig.inicializarBD();
        launch(args);

    }
}