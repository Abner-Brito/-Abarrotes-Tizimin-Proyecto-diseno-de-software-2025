package org.example.abarrotes_tizimin;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;
import org.example.abarrotes_tizimin.persistencia.DatabaseConfig;

/**
 * Clase principal de la aplicación Abarrotes Tizimín.
 * Inicializa la base de datos y muestra la ventana principal usando JavaFX.
 */
public class HelloApplication extends Application {
    /**
     * Método de inicio de JavaFX. Carga la vista principal y aplica el estilo.
     * @param stage Ventana principal de la aplicación.
     * @throws IOException Si ocurre un error al cargar el archivo FXML.
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader loader = new FXMLLoader(
            HelloApplication.class.getResource("/org/example/abarrotes_tizimin/vista/hello-view.fxml")
        );

        Scene scene = new Scene(loader.load(), 600, 400);

        scene.getStylesheets().add(
            HelloApplication.class.getResource("/css/styles.css").toExternalForm()
        );

        stage.setTitle("Abarrotes Tizimín");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Método principal. Inicializa la base de datos y lanza la aplicación JavaFX.
     * @param args Argumentos de línea de comandos.
     */
    public static void main(String[] args) {
        DatabaseConfig.inicializarBD();
        launch(args);
    }
}