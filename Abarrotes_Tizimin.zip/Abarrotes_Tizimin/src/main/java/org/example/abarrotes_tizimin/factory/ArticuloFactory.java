package org.example.abarrotes_tizimin.factory;

import org.example.abarrotes_tizimin.modelo.Articulo;

/**
 * Fábrica para crear instancias de Articulo de manera flexible.
 */
public class ArticuloFactory {
    /**
     * Crea un artículo con todos los campos especificados.
     * @param id ID del artículo.
     * @param nombre Nombre del artículo.
     * @param precio Precio de venta.
     * @param precioProveedor Precio de compra al proveedor.
     * @param stock Cantidad en inventario.
     * @param proveedor Nombre del proveedor.
     * @return Instancia de Articulo.
     */
    public static Articulo crearArticulo(int id, String nombre, double precio, double precioProveedor, int stock, String proveedor) {
        return new Articulo(id, nombre, precio, precioProveedor, stock, proveedor);
    }

    /**
     * Crea un artículo sin especificar el ID (por ejemplo, para nuevos registros).
     * @param nombre Nombre del artículo.
     * @param precio Precio de venta.
     * @param precioProveedor Precio de compra al proveedor.
     * @param stock Cantidad en inventario.
     * @param proveedor Nombre del proveedor.
     * @return Instancia de Articulo.
     */
    public static Articulo crearArticulo(String nombre, double precio, double precioProveedor, int stock, String proveedor) {
        return new Articulo(0, nombre, precio, precioProveedor, stock, proveedor);
    }
}