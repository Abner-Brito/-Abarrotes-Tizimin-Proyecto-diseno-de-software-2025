package org.example.abarrotes_tizimin.modelo;

/**
 * Representa la dirección de un cliente.
 * Incluye calle, número, colonia, código postal, ciudad y estado.
 */
public class Direccion {
    private String calle;
    private String numero;
    private String colonia;
    private String cp;
    private String ciudad;
    private String estado;

    /**
     * Constructor que inicializa todos los campos de la dirección.
     * @param calle Calle del domicilio.
     * @param numero Número exterior/interior.
     * @param colonia Colonia o barrio.
     * @param cp Código postal.
     * @param ciudad Ciudad.
     * @param estado Estado.
     */
    public Direccion(String calle, String numero, String colonia, String cp, String ciudad, String estado) {
        this.calle = calle;
        this.numero = numero;
        this.colonia = colonia;
        this.cp = cp;
        this.ciudad = ciudad;
        this.estado = estado;
    }

    public String getCalle() { return calle; }
    public void setCalle(String calle) { this.calle = calle; }
    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }
    public String getColonia() { return colonia; }
    public void setColonia(String colonia) { this.colonia = colonia; }
    public String getCp() { return cp; }
    public void setCp(String cp) { this.cp = cp; }
    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    /**
     * Devuelve la dirección en formato de texto.
     * @return Cadena con la dirección completa.
     */
    @Override
    public String toString() {
        return calle + " " + numero + ", " + colonia + ", " + cp + ", " + ciudad + ", " + estado;
    }
}