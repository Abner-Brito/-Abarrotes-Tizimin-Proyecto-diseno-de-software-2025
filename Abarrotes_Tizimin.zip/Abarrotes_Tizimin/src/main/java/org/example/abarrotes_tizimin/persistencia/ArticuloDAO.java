package org.example.abarrotes_tizimin.persistencia;

import org.example.abarrotes_tizimin.modelo.Articulo;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase de acceso a datos (DAO) para la entidad Articulo.
 * Permite realizar operaciones CRUD sobre la tabla de artículos en la base de datos.
 */
public class ArticuloDAO {

    /**
     * Obtiene todos los artículos almacenados en la base de datos.
     * @return Lista de objetos Articulo.
     */
    public static List<Articulo> obtenerTodosArticulos() {
        List<Articulo> articulos = new ArrayList<>();
        String sql = "SELECT id, nombre, precio, precio_proveedor, stock, proveedor FROM articulos";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Articulo articulo = new Articulo();
                articulo.setId(rs.getInt("id"));
                articulo.setNombre(rs.getString("nombre"));
                articulo.setPrecio(rs.getDouble("precio"));
                articulo.setPrecioProveedor(rs.getDouble("precio_proveedor"));
                articulo.setProveedor(rs.getString("proveedor"));
                articulo.setStock(rs.getInt("stock"));
                articulos.add(articulo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return articulos;
    }

    /**
     * Inserta un nuevo artículo en la base de datos.
     * @param articulo El artículo a insertar.
     * @return true si la operación fue exitosa, false en caso contrario.
     */
    public static boolean insertarArticulo(Articulo articulo) {
        String sql = "INSERT INTO articulos (nombre, precio, precio_proveedor, stock, proveedor) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, articulo.getNombre());
            pstmt.setDouble(2, articulo.getPrecio());
            pstmt.setDouble(3, articulo.getPrecioProveedor());
            pstmt.setInt(4, articulo.getStock());
            pstmt.setString(5, articulo.getProveedor());
            int filas = pstmt.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Actualiza el stock de un artículo restando la cantidad indicada.
     * @param id ID del artículo.
     * @param cantidad Cantidad a restar.
     * @return true si la operación fue exitosa, false en caso contrario.
     */
    public static boolean actualizarStock(int id, int cantidad) {
        String sql = "UPDATE articulos SET stock = stock - ? WHERE id = ? AND stock >= ?";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cantidad);
            pstmt.setInt(2, id);
            pstmt.setInt(3, cantidad);
            int filas = pstmt.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Elimina un artículo de la base de datos por su ID.
     * @param id ID del artículo a eliminar.
     * @return true si la operación fue exitosa, false en caso contrario.
     */
    public static boolean eliminarArticulo(int id) {
        String sql = "DELETE FROM articulos WHERE id = ?";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            int filas = pstmt.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Aumenta el stock de un artículo sumando la cantidad indicada.
     * @param id ID del artículo.
     * @param cantidad Cantidad a sumar.
     * @return true si la operación fue exitosa, false en caso contrario.
     */
    public static boolean aumentarStock(int id, int cantidad) {
        String sql = "UPDATE articulos SET stock = stock + ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getInstancia().getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cantidad);
            pstmt.setInt(2, id);
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}