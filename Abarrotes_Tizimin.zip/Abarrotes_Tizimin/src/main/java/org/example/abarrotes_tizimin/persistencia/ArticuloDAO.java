package org.example.abarrotes_tizimin.persistencia;

import org.example.abarrotes_tizimin.modelo.Articulo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ArticuloDAO {
public static List<Articulo> obtenerTodosArticulos() {
    List<Articulo> articulos = new ArrayList<>();
    String sql = "SELECT id, nombre, precio, precio_proveedor, stock, proveedor FROM articulos";

    try (Connection conn = DatabaseConfig.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {

        while (rs.next()) {
            Articulo articulo = new Articulo();
            articulo.setId(rs.getInt("id"));
            articulo.setNombre(rs.getString("nombre"));
            articulo.setPrecio(rs.getDouble("precio"));
            articulo.setPrecioProveedor(rs.getDouble("precio_proveedor"));
            articulo.setProveedor(rs.getString("proveedor"));
            articulo.setStock(rs.getInt("stock"));
            articulos.add(articulo);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }

    return articulos;
}

// src/main/java/org/example/abarrotes_tizimin/persistencia/ArticuloDAO.java
public static boolean insertarArticulo(Articulo articulo) {
    String sql = "INSERT INTO articulos (nombre, precio, precio_proveedor, stock, proveedor) VALUES (?, ?, ?, ?, ?)";
    try (Connection conn = DatabaseConfig.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, articulo.getNombre());
        pstmt.setDouble(2, articulo.getPrecio());
        pstmt.setDouble(3, articulo.getPrecioProveedor());
        pstmt.setString(4, articulo.getProveedor());
        pstmt.setInt(5, articulo.getStock());
        int filas = pstmt.executeUpdate();
        return filas > 0;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
    public static boolean actualizarStock(int id, int cantidad) {
        String sql = "UPDATE articulos SET stock = stock - ? WHERE id = ? AND stock >= ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cantidad);
            pstmt.setInt(2, id);
            pstmt.setInt(3, cantidad);
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    // src/main/java/org/example/abarrotes_tizimin/persistencia/ArticuloDAO.java
    public static boolean eliminarArticulo(int id) {
        String sql = "DELETE FROM articulos WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            int filas = pstmt.executeUpdate();
            return filas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public static boolean aumentarStock(int id, int cantidad) {
        String sql = "UPDATE articulos SET stock = stock + ? WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cantidad);
            pstmt.setInt(2, id);
            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}