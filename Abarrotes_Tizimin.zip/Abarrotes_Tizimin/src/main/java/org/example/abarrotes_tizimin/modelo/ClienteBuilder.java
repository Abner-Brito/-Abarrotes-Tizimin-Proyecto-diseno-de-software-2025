package org.example.abarrotes_tizimin.modelo;

/**
 * Builder para crear instancias de Cliente de manera flexible.
 */
public class ClienteBuilder {
    private String nombre;
    private String apellidoPaterno;
    private Direccion direccion;
    private String telefono;

    public ClienteBuilder setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    public ClienteBuilder setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
        return this;
    }

    public ClienteBuilder setDireccion(Direccion direccion) {
        this.direccion = direccion;
        return this;
    }

    public ClienteBuilder setTelefono(String telefono) {
        this.telefono = telefono;
        return this;
    }

    /**
     * Construye y devuelve una instancia de Cliente con los datos proporcionados.
     * @return Cliente creado.
     */
    public Cliente build() {
        return new Cliente(nombre, apellidoPaterno, direccion, telefono);
    }
}