package org.example.abarrotes_tizimin.modelo;

public class DetalleCompra {
    private Articulo articulo;
    private int cantidad;

    // Constructor
    public DetalleCompra(Articulo articulo, int cantidad) {
        this.articulo = articulo;
        this.cantidad = cantidad;
    }

    // Getters
    public Articulo getArticulo() {
        return articulo;
    }

    public int getCantidad() {
        return cantidad;
    }

    // Setters (opcional)
    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}