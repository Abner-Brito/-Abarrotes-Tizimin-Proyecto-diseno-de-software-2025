package org.example.abarrotes_tizimin.modelo;

/**
 * Representa el detalle de una compra, asociando un artículo y la cantidad adquirida.
 */
public class DetalleCompra {
    private Articulo articulo; // Artículo comprado
    private int cantidad;      // Cantidad adquirida

    /**
     * Constructor que inicializa el detalle con un artículo y una cantidad.
     * @param articulo El artículo comprado.
     * @param cantidad La cantidad adquirida.
     */
    public DetalleCompra(Articulo articulo, int cantidad) {
        this.articulo = articulo;
        this.cantidad = cantidad;
    }

    /**
     * Obtiene el artículo asociado a este detalle.
     * @return El artículo.
     */
    public Articulo getArticulo() {
        return articulo;
    }

    /**
     * Establece el artículo para este detalle.
     * @param articulo El artículo a asociar.
     */
    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    /**
     * Obtiene la cantidad adquirida.
     * @return La cantidad.
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * Establece la cantidad adquirida.
     * @param cantidad La cantidad a establecer.
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}