package org.example.abarrotes_tizimin.controlador;
import org.example.abarrotes_tizimin.modelo.Cliente;
import org.example.abarrotes_tizimin.persistencia.ClienteDAO;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.abarrotes_tizimin.modelo.Articulo;
import org.example.abarrotes_tizimin.modelo.DetalleCompra;
import org.example.abarrotes_tizimin.persistencia.ArticuloDAO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Label;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class RealizarCompraController {
    private final List<DetalleCompra> detallesCompra = new ArrayList<>();

    @FXML
    private ChoiceBox<Articulo> tablaArticulos;
    @FXML
    private TextField txtCantidad;

    @FXML
    private TableView<DetalleCompra> tablaDetalles;
    @FXML
    private TableColumn<DetalleCompra, String> colArticulo;
    @FXML
    private TableColumn<DetalleCompra, Integer> colCantidad;
    @FXML
    private TableColumn<DetalleCompra, Double> colPrecio;
    @FXML
    private TableColumn<DetalleCompra, Double> colSubtotal;
    @FXML
    private Label lblMensaje;
    @FXML
    private ChoiceBox<Cliente> choiceCliente;

    @FXML
    private void initialize() {
        // Cargar artículos en el ChoiceBox
        tablaArticulos.getItems().addAll(ArticuloDAO.obtenerTodosArticulos());
        choiceCliente.getItems().addAll(new ClienteDAO().obtenerTodosClientes());

        // Configurar columnas de la tabla
        colArticulo.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getArticulo().getNombre()));
        colCantidad.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getCantidad()).asObject());
        colPrecio.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getArticulo().getPrecio()).asObject());
        colSubtotal.setCellValueFactory(data -> {
            double subtotal = data.getValue().getArticulo().getPrecio() * data.getValue().getCantidad();
            return new SimpleDoubleProperty(subtotal).asObject();
        });

        // Inicializar la tabla vacía
        tablaDetalles.getItems().setAll(detallesCompra);
    }

@FXML
private void agregarArticulo() {
    lblMensaje.setText("");
    try {
        Cliente cliente = choiceCliente.getValue();
        if (cliente == null) {
            lblMensaje.setText("Selecciona un cliente.");
            return;
        }
        Articulo articulo = tablaArticulos.getValue();
        int cantidad = Integer.parseInt(txtCantidad.getText());

        if (articulo != null && cantidad > 0) {
            boolean exito = ArticuloDAO.actualizarStock(articulo.getId(), cantidad);
            if (!exito) {
                lblMensaje.setText("No hay suficiente stock para el artículo seleccionado.");
                return;
            }
            detallesCompra.add(new DetalleCompra(articulo, cantidad));
            tablaDetalles.getItems().setAll(detallesCompra);
            txtCantidad.clear();
        }
    } catch (NumberFormatException e) {
        lblMensaje.setText("Ingresa un número válido");
    }
}



@FXML
private void generarTicket() throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/abarrotes_tizimin/vista/ticket.fxml"));
    Stage stage = new Stage();
    Scene scene = new Scene(loader.load());

    TicketController controller = loader.getController();
    Cliente cliente = choiceCliente.getValue();
    String nombreCliente = cliente != null ? cliente.toString() : "";
    String fecha = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

    controller.generarTicket(detallesCompra, calcularTotal(), nombreCliente, fecha);

    stage.setScene(scene);
    stage.show();
}

    private double calcularTotal() {
        return detallesCompra.stream()
                .mapToDouble(d -> d.getArticulo().getPrecio() * d.getCantidad())
                .sum();
    }
}