package org.example.abarrotes_tizimin.controlador;

import org.example.abarrotes_tizimin.modelo.Cliente;
import org.example.abarrotes_tizimin.persistencia.ClienteDAO;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.abarrotes_tizimin.modelo.Articulo;
import org.example.abarrotes_tizimin.modelo.DetalleCompra;
import org.example.abarrotes_tizimin.persistencia.ArticuloDAO;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Label;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class RealizarCompraController {
    private final List<DetalleCompra> detallesCompra = new ArrayList<>();

    @FXML
    private ChoiceBox<Articulo> tablaArticulos;
    @FXML
    private TextField txtCantidad;
    @FXML
    private TableView<DetalleCompra> tablaDetalles;
    @FXML
    private TableColumn<DetalleCompra, String> colArticulo;
    @FXML
    private TableColumn<DetalleCompra, Integer> colCantidad;
    @FXML
    private TableColumn<DetalleCompra, Double> colPrecio;
    @FXML
    private TableColumn<DetalleCompra, Double> colSubtotal;
    @FXML
    private Label lblMensaje;
    @FXML
    private ChoiceBox<Cliente> choiceCliente;
    @FXML
    private TextField txtCantidadEliminar;

    @FXML
    private void initialize() {
        tablaArticulos.getItems().addAll(ArticuloDAO.obtenerTodosArticulos());
        choiceCliente.getItems().addAll(new ClienteDAO().obtenerTodosClientes());

        colArticulo.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getArticulo().getNombre()));
        colCantidad.setCellValueFactory(data -> new SimpleIntegerProperty(data.getValue().getCantidad()).asObject());
        colPrecio.setCellValueFactory(data -> new SimpleDoubleProperty(data.getValue().getArticulo().getPrecio()).asObject());
        colSubtotal.setCellValueFactory(data -> {
            double subtotal = data.getValue().getArticulo().getPrecio() * data.getValue().getCantidad();
            return new SimpleDoubleProperty(subtotal).asObject();
        });

        tablaDetalles.getItems().setAll(detallesCompra);
    }

    @FXML
    private void agregarArticulo() {
        lblMensaje.setText("");
        try {
            Cliente cliente = choiceCliente.getValue();
            if (cliente == null) {
                lblMensaje.setText("Selecciona un cliente.");
                return;
            }
            Articulo articulo = tablaArticulos.getValue();
            int cantidad = Integer.parseInt(txtCantidad.getText());

            if (articulo != null && cantidad > 0) {
                if (cantidad > articulo.getStock()) {
                    lblMensaje.setText("No hay suficiente stock para el artículo seleccionado.");
                    return;
                }
                // Si ya existe el artículo en la lista, suma la cantidad
                boolean encontrado = false;
                for (DetalleCompra detalle : detallesCompra) {
                    if (detalle.getArticulo().getId() == articulo.getId()) {
                        detalle.setCantidad(detalle.getCantidad() + cantidad);
                        encontrado = true;
                        break;
                    }
                }
                if (!encontrado) {
                    detallesCompra.add(new DetalleCompra(articulo, cantidad));
                }
                tablaDetalles.getItems().setAll(detallesCompra);
                txtCantidad.clear();
            }
        } catch (NumberFormatException e) {
            lblMensaje.setText("Ingresa un número válido");
        }
    }

    @FXML
    private void eliminarCantidadArticulo() {
        lblMensaje.setText("");
        Articulo articulo = tablaArticulos.getValue();
        if (articulo == null) {
            lblMensaje.setText("Selecciona un artículo para eliminar.");
            return;
        }
        int cantidadAEliminar;
        try {
            cantidadAEliminar = Integer.parseInt(txtCantidadEliminar.getText());
        } catch (NumberFormatException e) {
            lblMensaje.setText("Ingresa una cantidad válida a eliminar.");
            return;
        }
        if (cantidadAEliminar <= 0) {
            lblMensaje.setText("La cantidad debe ser mayor a 0.");
            return;
        }
        DetalleCompra detalleAEliminar = null;
        for (DetalleCompra detalle : detallesCompra) {
            if (detalle.getArticulo().getId() == articulo.getId()) {
                if (detalle.getCantidad() > cantidadAEliminar) {
                    detalle.setCantidad(detalle.getCantidad() - cantidadAEliminar);
                } else {
                    detalleAEliminar = detalle;
                }
                break;
            }
        }
        if (detalleAEliminar != null) {
            detallesCompra.remove(detalleAEliminar);
        }
        tablaDetalles.getItems().setAll(detallesCompra);
        txtCantidadEliminar.clear();
    }

    @FXML
    private void generarTicket() throws IOException {
        // Validar stock antes de descontar
        for (DetalleCompra detalle : detallesCompra) {
            if (detalle.getCantidad() > detalle.getArticulo().getStock()) {
                lblMensaje.setText("No hay suficiente stock para " + detalle.getArticulo().getNombre());
                return;
            }
        }
        // Descontar stock en la base de datos
        for (DetalleCompra detalle : detallesCompra) {
            ArticuloDAO.actualizarStock(detalle.getArticulo().getId(), detalle.getCantidad());
        }

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/abarrotes_tizimin/vista/ticket.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(loader.load());

        TicketController controller = loader.getController();
        Cliente cliente = choiceCliente.getValue();
        String nombreCliente = cliente != null ? cliente.toString() : "";
        String fecha = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

        controller.generarTicket(detallesCompra, calcularTotal(), nombreCliente, fecha);

        stage.setScene(scene);
        stage.setTitle("Ticket"); // Línea agregada para el título
        stage.show();

        // Limpiar lista de compras y tabla después de generar el ticket
        detallesCompra.clear();
        tablaDetalles.getItems().clear();

        // Recargar artículos con stock actualizado
        tablaArticulos.getItems().clear();
        tablaArticulos.getItems().addAll(ArticuloDAO.obtenerTodosArticulos());
    }

    private double calcularTotal() {
        return detallesCompra.stream()
                .mapToDouble(d -> d.getArticulo().getPrecio() * d.getCantidad())
                .sum();
    }
}