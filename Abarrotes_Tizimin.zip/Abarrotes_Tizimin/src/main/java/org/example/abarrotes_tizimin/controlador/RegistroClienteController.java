package org.example.abarrotes_tizimin.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import org.example.abarrotes_tizimin.modelo.Cliente;
import org.example.abarrotes_tizimin.modelo.ClienteBuilder;
import org.example.abarrotes_tizimin.modelo.Direccion;
import org.example.abarrotes_tizimin.persistencia.ClienteDAO;

/**
 * Controlador para la vista de registro de clientes.
 * Permite ingresar los datos de un nuevo cliente, validarlos y guardarlos en la base de datos.
 */
public class RegistroClienteController {

    /** Campo de texto para el nombre del cliente. */
    @FXML private TextField txtNombre;
    /** Campo de texto para el apellido paterno del cliente. */
    @FXML private TextField txtApellidoPaterno;
    /** Campo de texto para la calle de la dirección. */
    @FXML private TextField txtCalle;
    /** Campo de texto para el número de la dirección. */
    @FXML private TextField txtNumero;
    /** Campo de texto para la colonia de la dirección. */
    @FXML private TextField txtColonia;
    /** Campo de texto para el código postal. */
    @FXML private TextField txtCP;
    /** Campo de texto para la ciudad. */
    @FXML private TextField txtCiudad;
    /** Campo de texto para el estado. */
    @FXML private TextField txtEstado;
    /** Campo de texto para el teléfono del cliente. */
    @FXML private TextField txtTelefono;

    /**
     * Inicializa el controlador y agrega validaciones para que ciertos campos solo acepten números.
     */
    @FXML
    public void initialize() {
        txtTelefono.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                txtTelefono.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        txtNumero.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                txtNumero.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        txtCP.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*")) {
                txtCP.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
    }

    /**
     * Registra un nuevo cliente después de validar que todos los campos estén completos.
     * Muestra alertas en caso de error o éxito.
     */
    @FXML
    private void registrarCliente() {
        // Validación de campos obligatorios
        if (txtNombre.getText().isEmpty() ||
            txtApellidoPaterno.getText().isEmpty() ||
            txtCalle.getText().isEmpty() ||
            txtNumero.getText().isEmpty() ||
            txtColonia.getText().isEmpty() ||
            txtCP.getText().isEmpty() ||
            txtCiudad.getText().isEmpty() ||
            txtEstado.getText().isEmpty() ||
            txtTelefono.getText().isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Campos obligatorios");
            alert.setHeaderText(null);
            alert.setContentText("Por favor, llena todos los campos antes de registrar el cliente.");
            alert.showAndWait();
            return;
        }

        Direccion direccion = new Direccion(
                txtCalle.getText(),
                txtNumero.getText(),
                txtColonia.getText(),
                txtCP.getText(),
                txtCiudad.getText(),
                txtEstado.getText()
        );

        Cliente cliente = new ClienteBuilder()
                .setNombre(txtNombre.getText())
                .setApellidoPaterno(txtApellidoPaterno.getText())
                .setDireccion(direccion)
                .setTelefono(txtTelefono.getText())
                .build();

        ClienteDAO clienteDAO = new ClienteDAO();
        clienteDAO.guardarCliente(cliente);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Éxito");
        alert.setHeaderText(null);
        alert.setContentText("Cliente agregado con éxito");
        alert.showAndWait();

        txtNombre.clear();
        txtApellidoPaterno.clear();
        txtCalle.clear();
        txtNumero.clear();
        txtColonia.clear();
        txtCP.clear();
        txtCiudad.clear();
        txtEstado.clear();
        txtTelefono.clear();
    }
}