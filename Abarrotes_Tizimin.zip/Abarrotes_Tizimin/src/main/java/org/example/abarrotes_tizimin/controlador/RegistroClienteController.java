package org.example.abarrotes_tizimin.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import org.example.abarrotes_tizimin.modelo.Cliente;
import org.example.abarrotes_tizimin.modelo.Direccion;
import org.example.abarrotes_tizimin.persistencia.ClienteDAO;

public class RegistroClienteController {
    @FXML private TextField txtNombre;
    @FXML private TextField txtApellidoPaterno;
    @FXML private TextField txtCalle;
    @FXML private TextField txtNumero;
    @FXML private TextField txtColonia;
    @FXML private TextField txtCP;
    @FXML private TextField txtCiudad;
    @FXML private TextField txtEstado;
    @FXML private TextField txtTelefono;

    @FXML
    private void registrarCliente() {
        String nombre = txtNombre.getText();
        String apellido = txtApellidoPaterno.getText();
        String calle = txtCalle.getText();
        String numero = txtNumero.getText();
        String colonia = txtColonia.getText();
        String cp = txtCP.getText();
        String ciudad = txtCiudad.getText();
        String estado = txtEstado.getText();
        String telefono = txtTelefono.getText();

        Direccion direccion = new Direccion(calle, numero, colonia, cp, ciudad, estado);
        Cliente cliente = new Cliente(nombre, apellido, direccion, telefono);

        // Guardar cliente usando ClienteDAO (debes implementar este método)
        new ClienteDAO().insertarCliente(cliente);

        // Limpia los campos o muestra mensaje de éxito
    }
}