package org.example.abarrotes_tizimin.modelo;

import javafx.scene.control.Alert;
import java.util.List;

/**
 * Representa un artículo o producto en el sistema de abarrotes.
 * Contiene información relevante como nombre, precios, stock y proveedor.
 */
public class Articulo {
    private int id; // Identificador único del artículo
    private String nombre; // Nombre del artículo
    private double precio; // Precio de venta al público
    private double precioProveedor; // Precio de compra al proveedor
    private int stock; // Cantidad disponible en inventario
    private String proveedor; // Nombre del proveedor

    /**
     * Constructor completo para inicializar todos los campos del artículo.
     */
    public Articulo(int id, String nombre, double precio, double precioProveedor, int stock, String proveedor) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.precioProveedor = precioProveedor;
        this.stock = stock;
        this.proveedor = proveedor;
    }

    /**
     * Constructor vacío.
     */
    public Articulo() {}

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public double getPrecioProveedor() { return precioProveedor; }
    public int getStock() { return stock; }
    public String getProveedor() { return proveedor; }

    public void setId(int id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setPrecio(double precio) { this.precio = precio; }
    public void setPrecioProveedor(double precioProveedor) { this.precioProveedor = precioProveedor; }
    public void setStock(int stock) { this.stock = stock; }
    public void setProveedor(String proveedor) { this.proveedor = proveedor; }

    /**
     * Valida si hay suficiente stock para cada detalle de compra.
     * Muestra una alerta si algún artículo no tiene stock suficiente.
     * @param detalles Lista de detalles de compra a validar.
     * @return true si todos los artículos tienen stock suficiente, false en caso contrario.
     */
    public boolean validarStock(List<DetalleCompra> detalles) {
        for (DetalleCompra detalle : detalles) {
            Articulo articulo = detalle.getArticulo();
            if (detalle.getCantidad() > articulo.getStock()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error de stock");
                alert.setHeaderText(null);
                alert.setContentText("No hay suficiente stock para el artículo: " + articulo.getNombre());
                alert.showAndWait();
                return false;
            }
        }
        return true;
    }

    /**
     * Devuelve el nombre del artículo como representación en texto.
     */
    @Override
    public String toString() {
        return nombre;
    }
}