// src/main/java/org/example/abarrotes_tizimin/modelo/Articulo.java
package org.example.abarrotes_tizimin.modelo;

public class Articulo {
    private int id;
    private String nombre;
    private double precio; // precio al público
    private double precioProveedor;
    private int stock;
    private String proveedor;

    public Articulo(int id, String nombre, double precio, double precioProveedor, int stock, String proveedor) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.precioProveedor = precioProveedor;
        this.stock = stock;
        this.proveedor = proveedor;
    }

    public Articulo() {}

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public double getPrecioProveedor() { return precioProveedor; }
    public int getStock() { return stock; }
    public String getProveedor() { return proveedor; }

    public void setId(int id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setPrecio(double precio) { this.precio = precio; }
    public void setPrecioProveedor(double precioProveedor) { this.precioProveedor = precioProveedor; }
    public void setStock(int stock) { this.stock = stock; }
    public void setProveedor(String proveedor) { this.proveedor = proveedor; }


    @Override
    public String toString() {
        return nombre;
    }
}