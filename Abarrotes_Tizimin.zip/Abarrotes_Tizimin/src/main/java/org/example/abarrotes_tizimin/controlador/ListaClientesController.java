package org.example.abarrotes_tizimin.controlador;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.example.abarrotes_tizimin.modelo.Cliente;
import org.example.abarrotes_tizimin.persistencia.ClienteDAO;
import java.util.List;

public class ListaClientesController {
    @FXML
    private TableView<Cliente> tablaClientes;
    @FXML
    private TableColumn<Cliente, Integer> colId;
    @FXML
    private TableColumn<Cliente, String> colNombre;
    @FXML
    private TableColumn<Cliente, String> colApellido;
    @FXML
    private TableColumn<Cliente, String> colCalle;
    @FXML
    private TableColumn<Cliente, String> colNumero;
    @FXML
    private TableColumn<Cliente, String> colColonia;
    @FXML
    private TableColumn<Cliente, String> colCp;
    @FXML
    private TableColumn<Cliente, String> colCiudad;
    @FXML
    private TableColumn<Cliente, String> colEstado;
    @FXML
    private TableColumn<Cliente, String> colTelefono;

    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellido.setCellValueFactory(new PropertyValueFactory<>("apellidoPaterno"));
        colCalle.setCellValueFactory(new PropertyValueFactory<>("calle"));
        colNumero.setCellValueFactory(new PropertyValueFactory<>("numero"));
        colColonia.setCellValueFactory(new PropertyValueFactory<>("colonia"));
        colCp.setCellValueFactory(new PropertyValueFactory<>("cp"));
        colCiudad.setCellValueFactory(new PropertyValueFactory<>("ciudad"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));

        List<Cliente> clientes = new ClienteDAO().obtenerTodosClientes();
        tablaClientes.getItems().addAll(clientes);
    }
}