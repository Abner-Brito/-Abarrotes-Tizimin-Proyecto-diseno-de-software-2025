package org.example.abarrotes_tizimin.controlador;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import org.example.abarrotes_tizimin.modelo.Cliente;
import org.example.abarrotes_tizimin.modelo.Direccion;
import org.example.abarrotes_tizimin.persistencia.ClienteDAO;
import java.util.List;
import java.util.Optional;

public class ListaClientesController {
    @FXML private TableView<Cliente> tablaClientes;
    @FXML private TableColumn<Cliente, Integer> colId;
    @FXML private TableColumn<Cliente, String> colNombre;
    @FXML private TableColumn<Cliente, String> colApellido;
    @FXML private TableColumn<Cliente, String> colCalle;
    @FXML private TableColumn<Cliente, String> colNumero;
    @FXML private TableColumn<Cliente, String> colColonia;
    @FXML private TableColumn<Cliente, String> colCp;
    @FXML private TableColumn<Cliente, String> colCiudad;
    @FXML private TableColumn<Cliente, String> colEstado;
    @FXML private TableColumn<Cliente, String> colTelefono;

    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellido.setCellValueFactory(new PropertyValueFactory<>("apellidoPaterno"));
        colCalle.setCellValueFactory(new PropertyValueFactory<>("calle"));
        colNumero.setCellValueFactory(new PropertyValueFactory<>("numero"));
        colColonia.setCellValueFactory(new PropertyValueFactory<>("colonia"));
        colCp.setCellValueFactory(new PropertyValueFactory<>("cp"));
        colCiudad.setCellValueFactory(new PropertyValueFactory<>("ciudad"));
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));

        List<Cliente> clientes = new ClienteDAO().obtenerTodosClientes();
        tablaClientes.getItems().addAll(clientes);
    }

    @FXML
    private void eliminarCliente() {
        Cliente seleccionado = tablaClientes.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarAlerta("Selecciona un cliente para eliminar.", Alert.AlertType.WARNING);
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "¿Seguro que deseas eliminar este cliente?", ButtonType.YES, ButtonType.NO);
        Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.YES) {
            boolean exito = new ClienteDAO().eliminarCliente(seleccionado.getId());
            if (exito) {
                tablaClientes.getItems().remove(seleccionado);
                mostrarAlerta("Cliente eliminado correctamente.", Alert.AlertType.INFORMATION);
            } else {
                mostrarAlerta("No se pudo eliminar el cliente.", Alert.AlertType.ERROR);
            }
        }
    }

    @FXML
    private void editarCliente() {
        Cliente seleccionado = tablaClientes.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            mostrarAlerta("Selecciona un cliente para editar.", Alert.AlertType.WARNING);
            return;
        }

        Dialog<Cliente> dialog = new Dialog<>();
        dialog.setTitle("Editar Cliente");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(10);

        TextField nombre = new TextField(seleccionado.getNombre());
        TextField apellido = new TextField(seleccionado.getApellidoPaterno());
        TextField calle = new TextField(seleccionado.getCalle());
        TextField numero = new TextField(seleccionado.getNumero());
        TextField colonia = new TextField(seleccionado.getColonia());
        TextField cp = new TextField(seleccionado.getCp());
        TextField ciudad = new TextField(seleccionado.getCiudad());
        TextField estado = new TextField(seleccionado.getEstado());
        TextField telefono = new TextField(seleccionado.getTelefono());

        // Listeners para solo números
        telefono.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("\\d*")) {
                telefono.setText(newVal.replaceAll("[^\\d]", ""));
            }
        });
        numero.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("\\d*")) {
                numero.setText(newVal.replaceAll("[^\\d]", ""));
            }
        });
        cp.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("\\d*")) {
                cp.setText(newVal.replaceAll("[^\\d]", ""));
            }
        });

        grid.addRow(0, new Label("Nombre:"), nombre);
        grid.addRow(1, new Label("Apellido:"), apellido);
        grid.addRow(2, new Label("Calle:"), calle);
        grid.addRow(3, new Label("Número:"), numero);
        grid.addRow(4, new Label("Colonia:"), colonia);
        grid.addRow(5, new Label("CP:"), cp);
        grid.addRow(6, new Label("Ciudad:"), ciudad);
        grid.addRow(7, new Label("Estado:"), estado);
        grid.addRow(8, new Label("Teléfono:"), telefono);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                if (nombre.getText().isEmpty() || apellido.getText().isEmpty() || calle.getText().isEmpty() ||
                    numero.getText().isEmpty() || colonia.getText().isEmpty() || cp.getText().isEmpty() ||
                    ciudad.getText().isEmpty() || estado.getText().isEmpty() || telefono.getText().isEmpty()) {
                    mostrarAlerta("Todos los campos son obligatorios.", Alert.AlertType.ERROR);
                    return null;
                }
                Direccion direccion = new Direccion(
                        calle.getText(), numero.getText(), colonia.getText(), cp.getText(), ciudad.getText(), estado.getText()
                );
                Cliente editado = new Cliente(nombre.getText(), apellido.getText(), direccion, telefono.getText());
                editado.setId(seleccionado.getId());
                return editado;
            }
            return null;
        });

        Optional<Cliente> resultado = dialog.showAndWait();
        resultado.ifPresent(clienteEditado -> {
            boolean exito = new ClienteDAO().actualizarCliente(clienteEditado);
            if (exito) {
                int idx = tablaClientes.getItems().indexOf(seleccionado);
                tablaClientes.getItems().set(idx, clienteEditado);
                mostrarAlerta("Cliente actualizado correctamente.", Alert.AlertType.INFORMATION);
            } else {
                mostrarAlerta("No se pudo actualizar el cliente.", Alert.AlertType.ERROR);
            }
        });
    }

    private void mostrarAlerta(String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}