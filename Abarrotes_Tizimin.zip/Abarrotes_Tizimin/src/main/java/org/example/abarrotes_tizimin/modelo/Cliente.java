// src/main/java/org/example/abarrotes_tizimin/modelo/Cliente.java
package org.example.abarrotes_tizimin.modelo;

public class Cliente {
    private int id;
    private String nombre;
    private String apellidoPaterno;
    private Direccion direccion;
    private String telefono;
    private String calle;
    private String numero;
    private String colonia;
    private String cp;
    private String ciudad;
    private String estado;

    public Cliente(String nombre, String apellidoPaterno, Direccion direccion, String telefono) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.direccion = direccion;
        this.telefono = telefono;
        if (direccion != null) {
            this.calle = direccion.getCalle();
            this.numero = direccion.getNumero();
            this.colonia = direccion.getColonia();
            this.cp = direccion.getCp();
            this.ciudad = direccion.getCiudad();
            this.estado = direccion.getEstado();
        }
    }

    // Getters y setters para todos los campos

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellidoPaterno() { return apellidoPaterno; }
    public void setApellidoPaterno(String apellidoPaterno) { this.apellidoPaterno = apellidoPaterno; }
    public Direccion getDireccion() { return direccion; }
    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
        if (direccion != null) {
            this.calle = direccion.getCalle();
            this.numero = direccion.getNumero();
            this.colonia = direccion.getColonia();
            this.cp = direccion.getCp();
            this.ciudad = direccion.getCiudad();
            this.estado = direccion.getEstado();
        }
    }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getCalle() { return calle; }
    public void setCalle(String calle) { this.calle = calle; }
    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }
    public String getColonia() { return colonia; }
    public void setColonia(String colonia) { this.colonia = colonia; }
    public String getCp() { return cp; }
    public void setCp(String cp) { this.cp = cp; }
    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    @Override
    public String toString() {
        return nombre + (apellidoPaterno != null ? " " + apellidoPaterno : "");
    }
}