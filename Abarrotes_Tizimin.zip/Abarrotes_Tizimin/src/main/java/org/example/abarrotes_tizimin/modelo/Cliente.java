package org.example.abarrotes_tizimin.modelo;

/**
 * Representa un cliente del sistema.
 * Incluye información personal y de dirección.
 */
public class Cliente {
    private int id; // Identificador único del cliente
    private String nombre; // Nombre del cliente
    private String apellidoPaterno; // Apellido paterno
    private Direccion direccion; // Objeto con los datos de dirección
    private String telefono; // Teléfono de contacto
    // Campos individuales de dirección para facilitar el acceso
    private String calle;
    private String numero;
    private String colonia;
    private String cp;
    private String ciudad;
    private String estado;

    /**
     * Constructor principal que recibe los datos y la dirección.
     */
    public Cliente(String nombre, String apellidoPaterno, Direccion direccion, String telefono) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.direccion = direccion;
        this.telefono = telefono;
        if (direccion != null) {
            this.calle = direccion.getCalle();
            this.numero = direccion.getNumero();
            this.colonia = direccion.getColonia();
            this.cp = direccion.getCp();
            this.ciudad = direccion.getCiudad();
            this.estado = direccion.getEstado();
        }
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellidoPaterno() { return apellidoPaterno; }
    public void setApellidoPaterno(String apellidoPaterno) { this.apellidoPaterno = apellidoPaterno; }
    public Direccion getDireccion() { return direccion; }
    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
        if (direccion != null) {
            this.calle = direccion.getCalle();
            this.numero = direccion.getNumero();
            this.colonia = direccion.getColonia();
            this.cp = direccion.getCp();
            this.ciudad = direccion.getCiudad();
            this.estado = direccion.getEstado();
        }
    }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    public String getCalle() { return calle; }
    public void setCalle(String calle) { this.calle = calle; }
    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }
    public String getColonia() { return colonia; }
    public void setColonia(String colonia) { this.colonia = colonia; }
    public String getCp() { return cp; }
    public void setCp(String cp) { this.cp = cp; }
    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    /**
     * Devuelve el nombre completo del cliente como representación en texto.
     */
    @Override
    public String toString() {
        return nombre + (apellidoPaterno != null ? " " + apellidoPaterno : "");
    }
}