module org.example.abarrotes_tizimin {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires java.sql;

    exports org.example.abarrotes_tizimin.controlador;
    opens org.example.abarrotes_tizimin.controlador to javafx.fxml;
    exports org.example.abarrotes_tizimin.persistencia;
    opens org.example.abarrotes_tizimin.persistencia to javafx.fxml;
    exports org.example.abarrotes_tizimin;
    opens org.example.abarrotes_tizimin to javafx.fxml;
    opens org.example.abarrotes_tizimin.modelo to javafx.base;
}